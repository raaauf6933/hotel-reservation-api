const cloudinary = require("cloudinary");

module.exports = () => {
  cloudinary.v2.config({
    cloud_name:'dwnnnqffb',
    api_key: "673559779621746",
    api_secret: "Q_3CjRimrVVrjlsPnx_fW1L4TRU",
  });
};
